// aria-current="page"

document.querySelectorAll('.nav-links a').forEach(link => {
    if(link.href === window.location.href){
        link.setAttribute('aria-current', 'page');
    };
})







